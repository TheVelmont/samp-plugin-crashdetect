#include <stdio.h>

extern "C" void foo() {
  puts("foo() called");
}
