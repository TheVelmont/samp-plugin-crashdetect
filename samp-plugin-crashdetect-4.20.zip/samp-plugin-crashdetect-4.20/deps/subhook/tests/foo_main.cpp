extern "C" void foo(void);

int main() {
    foo();
    return 0;
}
